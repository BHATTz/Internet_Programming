/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import static com.sun.tools.attach.VirtualMachine.list;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import static java.util.Collections.list;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import static jdk.javadoc.internal.doclets.toolkit.util.DocFile.list;

/**
 *
 * @author Sushant
 */
@WebServlet(urlPatterns = {"/AdminPage"})
public class AdminPage extends HttpServlet {
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request, response);
    }


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<body style='text-align:center'>");
        out.println("<h1>Hello, Admin</h1>");
        out.println("<h1>Welcome to Profile</h1>");
        out.println("<h3>Here are all the users:</h3>");
        out.print("<table border='1' width='50%' style='margin-left:auto;margin-right:auto'>");
        out.println("<tr><th>ID</th><th>Name</th><th>Password</th><th>Email</th><th>Country</th><th>Delete</th><th>Modify</th></tr>");
        List<GetSet> list = Functions.getAll();
        for (GetSet e : list) {
            out.print("<tr><td>" + e.getId() + "</td><td>" + e.getName() + "</td><td>" + e.getPassword()
                    + "</td><td>" + e.getEmail() + "</td><td>" + e.getCountry() + "</td><td><a href='EditServlet?id="
                    + e.getId() + "'>Edit</a></td><td><a href='DeleteServlet?id=" + e.getId()
                    + "'>Delete</a></td></tr>");
        }

        out.println("</table></body>");

    }
}
