package com.sushant.Experiment32;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

public class App {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Configuration con = new Configuration().configure().addAnnotatedClass(SecondClass.class);
		ServiceRegistry reg = new ServiceRegistryBuilder().applySettings(con.getProperties()).buildServiceRegistry();
		SessionFactory sf = con.buildSessionFactory(reg);
		Session session = sf.openSession();
		Transaction tx = session.beginTransaction();

		boolean exit = true;
		while (exit) {
			System.out.println("Enter operation number:\n1. Create\n2. Read\n3. Update\n4. Delete\n5. Exit");
			int operation = sc.nextInt();
			switch (operation) {
			case 1:
				// Create operation using Hibernate
				SecondClass obj = new SecondClass();
				obj.setId(0);
				obj.setName("Hibernate");
				obj.setPass("TestPassword");
				obj.setEmail("Hibernate@gmail.com");
				obj.setCountry("India");
				session.save(obj);
				System.out.println("\nEntery Created!");
				break;

			case 2:
				// Read Operation using Hibernate
				int objId = 0;
				SecondClass objRead = (SecondClass) session.get(SecondClass.class, objId);
				System.out.println("ID: " + objRead.getId());
				System.out.println("Name: " + objRead.getName());
				System.out.println("Password: " + objRead.getPass());
				System.out.println("Email: " + objRead.getEmail());
				System.out.println("Country: " + objRead.getCountry());
				break;

			case 3:
				// Update Operation using Hibernate
				objId = 0;
				SecondClass objUpdate = (SecondClass) session.get(SecondClass.class, objId);
				objUpdate.setName("Updated Name");
				objUpdate.setPass("Updated Password");
				objUpdate.setEmail("updated_email@gmail.com");
				objUpdate.setCountry("USA");
				session.update(objUpdate);
				System.out.println("\nEntery Updated!");

				System.out.println("ID: " + objUpdate.getId());
				System.out.println("Name: " + objUpdate.getName());
				System.out.println("Password: " + objUpdate.getPass());
				System.out.println("Email: " + objUpdate.getEmail());
				System.out.println("Country: " + objUpdate.getCountry());
				break;

			case 4:
				// Delete Operation using Hibernate
				objId = 0;
				SecondClass objDel = (SecondClass) session.get(SecondClass.class, objId);
				session.delete(objDel);
				System.out.println("\nEntery Deleted!");
				break;
			case 5:
				exit = false;
				break;

			default:
				System.out.println("Invalid operation number!");
				break;
			}

		}
		
		tx.commit();
		sc.close();
		session.close();

	}
}