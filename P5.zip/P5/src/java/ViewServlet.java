/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import java.util.List;

import java.io.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ViewServlet")
public class ViewServlet extends HttpServlet {
  
  @Override
  protected void doGet(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
    
    response.setContentType("text/html");
    PrintWriter out = response.getWriter();
    
    out.println("<a href='index.html'>Add New Employee</a>");
    out.println("<h1>Employees List</h1>");
    
    List<Emp> employeeList = EmpDao.getAllEmployees();
    
    out.print("<table border='1' width='100%'>");
    out.print("<tr><th>Id</th><th>Name</th><th>Password</th><th>Email</th><th>Country</th><th>Edit</th><th>Delete</th></tr>");
    
    for (Emp emp : employeeList) {
      out.print("<tr><td>" + emp.getId() + "</td><td>" + emp.getName() + "</td><td>" + emp.getPassword() + "</td><td>" + emp.getEmail() + "</td><td>" + emp.getCountry() + "</td>");
      out.print("<td><a href='EditServlet?id=" + emp.getId() + "'>edit</a></td>");
      out.print("<td><a href='DeleteServlet?id=" + emp.getId() + "'>delete</a></td></tr>");
    }
    
    out.print("</table>");
    out.close();
  }
}
