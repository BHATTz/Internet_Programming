const mysql = require("mysql");

var conn = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "aip",
});

conn.connect(function (err) {
  if (err) throw console.log("Error", err);
  console.log("Connected to DB");
});

var createSQL =
  "INSERT INTO users(name,pass,email,country) VALUES('NodeJS','NodeJSPass','NodeJs@gmail.com','India')";
var updateSQL = "UPDATE users SET name='Updated_NodeJS' WHERE name='NodeJs'";
var readSQL = "SELECT * FROM users where name ='NodeJS'";
var deleteSQL = "DELETE FROM users WHERE users.name = 'Updated_NodeJS'";

conn.query(createSQL, function (err) {
  if (err) throw err;
  console.log("Inserted entry for NodeJs.");
});

conn.query(readSQL, function (err, result) {
  if (err) throw err;
  console.log(result);
});

conn.query(updateSQL, function (err, result) {
  if (err) throw err;
  console.log(result.affectedRows + " row(s) updated");
});

var readSQL = "SELECT * FROM users where name ='Updated_NodeJS'";

conn.query(readSQL, function (err, result) {
  if (err) throw err;
  console.log(result);
});
conn.query(deleteSQL, function (err, result) {
  if (err) throw err;
  console.log("Deleted " + result.affectedRows + " Entery!");
});

conn.end();
