package com.sushant.Experiment31;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

public class App 
{
    public static void main( String[] args )
    {
        
        SecondClass obj = new SecondClass();
        
        obj.setId(0);
        obj.setName("First_Hibernate");
        obj.setPass("TestPassword");
        obj.setEmail("First_Hibernate@gmail.com");
        obj.setCountry("India");
        
        
        Configuration con = new Configuration().configure().addAnnotatedClass(SecondClass.class);
        
        
        ServiceRegistry reg = new ServiceRegistryBuilder().applySettings(con.getProperties()).buildServiceRegistry();
        
        
        SessionFactory sf = con.buildSessionFactory(reg);
        Session session = sf.openSession();
        Transaction tx = session.beginTransaction();
        
        session.save(obj);
        
        tx.commit();
    }
}
