//Read file
const fileSystem = require("fs");
console.log("Before Reading");
fileSystem.readFile("ex.9/a.txt", "utf-8", (err, data) => {
  if (err) throw err;
  console.log(data);
  console.log("read File");
});
//write file
const textToBeWritten = "New File Created !";
fileSystem.writeFileSync("c.txt", textToBeWritten);
console.log("Creating and Writing to File DONE! smile");
