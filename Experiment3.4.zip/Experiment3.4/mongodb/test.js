//npm install mongodb
const MongoClient = require("mongodb").MongoClient;
const url = "mongodb://127.0.0.1:27017";
const client = new MongoClient(url);
const dbName = "MCA"; // database name

async function addEntry(entry) {
  let result = await client.connect();
  console.log("---------------Connected To DB---------------");
  let db = result.db(dbName);
  let collection = db.collection("AIP");
  await collection.insertOne(entry);
  console.log("Node entry added!");
}

async function readEntries() {
  let result = await client.connect();
  console.log("---------------Connected To DB---------------");
  console.log("Reading all Entries:");
  let db = result.db(dbName);
  let collection = db.collection("AIP");
  let response = await collection.find({}).toArray();
  console.log(response);
}

async function deleteEntry(entry) {
  let result = await client.connect();
  console.log("---------------Connected To DB---------------");
  let db = result.db(dbName);
  let collection = db.collection("AIP");
  await collection.deleteOne(entry);
  console.log("Node entry deleted!");
}

async function main() {
  try {
    await addEntry({
      id: "1",
      name: "NodeJs",
      pass: "NodeJsPass",
      email: "NodeJs@email.com",
      country: "India",
    });

    await readEntries();
    await deleteEntry({ name: "NodeJs" });
    await readEntries();
  } catch (error) {
    console.error(error);
  } finally {
    await client.close();
  }
}

main();
