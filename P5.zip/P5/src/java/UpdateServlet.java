/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import java.io.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/UpdateServlet")
public class UpdateServlet extends HttpServlet {
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        // Get employee ID from request parameter
        String sid = request.getParameter("id");
        int id = Integer.parseInt(sid);
        
        // Get updated employee details from request parameters
        String name = request.getParameter("name");
        String password = request.getParameter("password");
        String email = request.getParameter("email");
        String country = request.getParameter("country");
        
        // Create an instance of the employee and set its properties
        Emp e = new Emp();
        e.setId(id);
        e.setName(name);
        e.setPassword(password);
        e.setEmail(email);
        e.setCountry(country);
        
        // Call the DAO method to update the employee record
        int status = EmpDao.update(e);
        
        if(status > 0) {
            // Redirect to the ViewServlet to display the updated employee record
            response.sendRedirect("ViewServlet");
        } else {
            out.println("Sorry! Unable to update record.");
        }
        
        out.close();
}
}
