/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Sushant
 */
@WebServlet(urlPatterns = {"/UserPage"})
public class UserPage extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("username") == null) {
            response.sendRedirect("index.html");
            
            return;
        }
         String name = (String) session.getAttribute("username");
        
        Connection conn = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/aip", "root", "");
            PreparedStatement ps = conn.prepareStatement("select * from users where name=?");
            ps.setString(1, name);
            ResultSet rs = ps.executeQuery();
            out.println("<body style='text-align:center'>");
            out.println("<h1>Hello, " + name + "</h1>");
            out.println("<h1>Welcome to Profile</h1>");
            out.print("<table border='1' width='50%' style='margin-left:auto;margin-right:auto'>");
            out.println("<tr><th>Your ID</th><th>Your Name</th><th>Your Password</th><th>Your Email</th><th>Your Country</th></tr>");
            if(rs.next()) {
                out.println("<tr><td>" + rs.getString(1) + "</td><td>" + rs.getString(2) + "</td><td>" + rs.getString(3) + "</td><td>" + rs.getString(4) + "</td><td>" + rs.getString(5) + "</td></tr>");
            }
            out.println("</table></body>");
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}
